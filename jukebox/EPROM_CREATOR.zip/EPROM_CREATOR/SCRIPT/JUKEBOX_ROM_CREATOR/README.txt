
Set EXECUTABLE permissions to all .sh file.
